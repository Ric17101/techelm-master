package admin4.techelm.com.techelmtechnologies.webservice.interfaces;

import admin4.techelm.com.techelmtechnologies.webservice.model.WebResponse;

public interface OnServiceListener {
	 void onServiceCallback(WebResponse response);
}