package admin4.techelm.com.techelmtechnologies.webservice.command;

/**
 * Created by jcf on 7/29/2016.
 */
public class DeleteCommand {
}
